# sma

Descrição:
O pacote smd tem uma estrutura:
    Processo:
        - Saída 
## Instalação

Use o gerenciador de pacotes [pip](https://pip.pypa.io/en/stable/) para instalar o pacote sma

'''bash
pip install smd
'''

## Author
Daniel 
